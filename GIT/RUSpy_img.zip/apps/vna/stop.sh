#! /bin/sh

killall -q vna
